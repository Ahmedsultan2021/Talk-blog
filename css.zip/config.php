<?php
    define("DB_NAME" ,"blog");
    define("DB_USER_NAME" ,"root");
    define("DB_USER_PW" ,"");
    define("DB_HOST" ,"localhost");

